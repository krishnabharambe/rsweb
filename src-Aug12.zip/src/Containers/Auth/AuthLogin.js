import React from "react";
import ValidatePhone from "../../Components/Auth/ValidatePhone";
import { useSelector } from "react-redux";
import ValidateOtp from "../../Components/Auth/ValidateOtp";
import Register from "../../Components/Auth/Register";
import Login from "../../Components/Auth/Login";
import Login2 from "../../Components/Auth/Login2";
// import { Container } from './styles';

function AuthLogin() {
//   const state = useSelector((state) => state);
  return (
  <Login2 /> 
  );
}

export default AuthLogin;
