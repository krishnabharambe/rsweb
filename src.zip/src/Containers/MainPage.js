import React from 'react';
import { useSelector } from 'react-redux';
import Auth from './Auth/Auth';

// import { Container } from './styles';

function MainPage() {
    const state = useSelector((state) => state);
  return (
      <div>
      {state.isAuthenticated ? "you are in" : <Auth /> }
      </div>
  );
}

export default MainPage;