import ValidatePhone from "./Components/Auth/ValidatePhone";
import Auth from "./Containers/Auth/Auth";
import * as actions from './Redux/Actions/Auth';
import { connect } from 'react-redux';
import MainPage from "./Containers/MainPage";
function App() {
  return (
    <div>
      <MainPage/>
    </div>
  );
}

export default (App);
